//
//  Constants.h
//  Hyderabad Bazar
//
//  Created by kireeti on 28/01/14.
//  Copyright (c) 2014 Madhavi KireetiSoft technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

#pragma mark--- Color keys ---


#define KStringCompanyName @"SriBalaji SaiRam Chit Fund Pvt. Ltd."
#define kImageLogo @"sbsr small.png"
#define APPREDCOLOR [UIColor colorWithRed:(174.0/255.0) green:(0.0/255.0) blue:(0.0/255.0) alpha:1]
#pragma mark -------- Array Strings ------------

@interface Constants : UIViewController

@end
