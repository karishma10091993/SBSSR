//
//  ViewController.h
//  AvenueChits
//
//  Created by kireeti on 19/04/16.
//  Copyright © 2016 KireetiSoftSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"

@interface ViewController : UIViewController

-(float)viewWidth;
-(float)viewHeight;
-(void)setcolourofbutton:(UIButton *)button stringtitle:(NSString *)titlebtn;
@end

